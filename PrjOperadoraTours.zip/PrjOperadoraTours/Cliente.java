public class Cliente {
    public static final String CONDICION_NACIONAL = "nacional";

    private String nombre;
    private String condicion;

    public Cliente(String nombre, String condicion) {
        this.nombre = nombre;
        this.condicion = condicion;
    }

    public String getNombre() {
        return nombre;
    }

    public boolean esNacional() {
        return condicion.equalsIgnoreCase(CONDICION_NACIONAL);
    }

    public String toString() {
        return "Nombre = " + nombre +
               " Condición = " + condicion;
    }
}
