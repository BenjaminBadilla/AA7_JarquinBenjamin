import java.util.ArrayList;

public abstract class Tour {
    public static final String PREFIJO_CODIGO = "TOUR-";
    public static final double PORCENTAJE_DESCUENTO_NACIONAL = 0.20;
    public static final int CANTIDAD_PERSONAS_POR_OMISION = 1;

    private String codigo;
    private String nombre;
    protected double precioBase;
    private int cupoMaximo;
    private Guia guia;
    protected ArrayList<Atractivo> recorrido;
    private ArrayList<Reserva> reservas;
    private static int cantidadTours;

    public Tour(String nombre, double precioBase, int cupoMaximo, Guia guia) {
        cantidadTours++;
        codigo = PREFIJO_CODIGO + cantidadTours;
        this.nombre = nombre;
        this.precioBase = precioBase;
        this.cupoMaximo = cupoMaximo;
        this.guia = guia;
        recorrido = new ArrayList<>();
        reservas = new ArrayList<>();
    }

    public abstract double calcularPrecioPorPersona();

    public void cambiarGuia(Guia nuevaGuia) {
        guia = nuevaGuia;
    }

    public void agregarAtractivo(Atractivo a) {
        if (!recorrido.contains(a)) {
            recorrido.add(a);
        }
    }

    public void registrarReserva(Cliente c, int cantidadPersonas) {
        if (cantidadPersonas > 0 && cantidadPersonas <= calcularCuposDisponibles()) {
            double monto = calcularMontoReserva(c, cantidadPersonas);
            reservas.add(new Reserva(generarNumeroReserva(), c.getNombre(), cantidadPersonas, monto));
        }
    }

    public void registrarReserva(Cliente c) {
        registrarReserva(c, CANTIDAD_PERSONAS_POR_OMISION);
    }

    public final double calcularMontoReserva(Cliente c, int cantidadPersonas) {
        double monto = calcularPrecioPorPersona() * cantidadPersonas;
        if (c.esNacional()) {
            monto = monto - (monto * PORCENTAJE_DESCUENTO_NACIONAL);
        }
        return monto;
    }

    public final double calcularIngresoTotal() {
        double total = 0;
        for (Reserva r : reservas) {
            total += r.getMonto();
        }
        return total;
    }

    public String consultarNombreGuia() {
        return guia.getNombreCompleto();
    }

    public String consultarNombresAtractivos() {
        String s = "";
        for (int i = 0; i < recorrido.size(); i++) {
            if (i > 0 && i == recorrido.size() - 1) {
                s += " y ";
            } else if (i > 0) {
                s += ", ";
            }
            s += recorrido.get(i).getNombre();
        }
        return s;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public static int getCantidadTours() {
        return cantidadTours;
    }

    private int calcularCuposDisponibles() {
        int ocupados = 0;
        for (Reserva r : reservas) {
            ocupados += r.getCantidadPersonas();
        }
        return cupoMaximo - ocupados;
    }

    private int generarNumeroReserva() {
        return reservas.size() + 1;
    }

    public String toString() {
        String s = "Código: " + codigo +
                   "\nNombre: " + nombre +
                   "\nGuía: " + consultarNombreGuia() +
                   "\nPrecio base: " + precioBase +
                   "\nPrecio por persona: " + calcularPrecioPorPersona() +
                   "\nCupo máximo: " + cupoMaximo +
                   "\nCupos disponibles: " + calcularCuposDisponibles() +
                   "\nRecorrido: " + consultarNombresAtractivos() +
                   "\nReservas (" + reservas.size() + "):\n";
        for (Reserva r : reservas) {
            s += "- " + r + "\n";
        }
        s += "Ingreso total: " + calcularIngresoTotal() + "\n";
        return s;
    }
}
