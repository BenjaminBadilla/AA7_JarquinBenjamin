public class TourCultural extends Tour {
    private String idioma;

    public TourCultural(String nombre, double precioBase, int cupoMaximo, Guia guia, String idioma) {
        super(nombre, precioBase, cupoMaximo, guia);
        this.idioma = idioma;
    }

    public double calcularPrecioPorPersona() {
        double precio = precioBase;
        for (Atractivo a : recorrido) {
            precio += a.getMontoEntrada();
        }
        return precio;
    }

    public String toString() {
        String s = super.toString();
        s = s + "Tipo de tour: Cultural\n" +
                "Idioma: " + idioma + "\n";
        return s;
    }
}
